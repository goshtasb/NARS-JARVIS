/* canvas.jsx — Tab 2: the task board (Now · Scheduled · Activity). */
(function () {
  const { useState, useRef, useEffect } = React;
  const { byId, CATALOG, relTime, clockTime } = window.JARVIS;
  const Icon = window.Icon;

  const STATE_META = {
    queued:    { label: 'Queued',    icon: 'hourglass',        cls: 'queued' },
    running:   { label: 'Running',   icon: 'play',             cls: 'running' },
    working:   { label: 'Working',   icon: 'play',             cls: 'working' },
    done:      { label: 'Done',      icon: 'checkmark.circle', cls: 'done' },
    failed:    { label: 'Failed',    icon: 'xmark.octagon',    cls: 'failed' },
    held:      { label: 'Needs approval', icon: 'pause',       cls: 'held' },
    scheduled: { label: 'Scheduled', icon: 'calendar',         cls: 'scheduled' },
  };

  function StateBadge({ state }) {
    const m = STATE_META[state]; if (!m) return null;
    return <span className={'badge ' + m.cls}><Icon name={m.icon} size={11} /> {m.label}</span>;
  }

  /* ---- alternative-tool dropdown (failed recovery) ---- */
  function ChangeToolMenu({ task, onPick, onClose }) {
    // alternatives accept the same target kind
    const isFile = (task.targetFull || task.target || '').match(/\.(pdf|md|txt|xlsx|docx|csv)$/i) || (task.targetFull||'').startsWith('/');
    const alts = CATALOG.filter(v => v.id !== task.verb && (isFile ? (v.target === 'file') : (v.target === 'url' || v.target === 'query')));
    const ref = useRef(null);
    useEffect(() => {
      const h = (e) => { if (ref.current && !ref.current.contains(e.target)) onClose(); };
      const k = (e) => { if (e.key === 'Escape') onClose(); };
      document.addEventListener('mousedown', h); document.addEventListener('keydown', k);
      return () => { document.removeEventListener('mousedown', h); document.removeEventListener('keydown', k); };
    }, [onClose]);
    return (
      <div className="tool-menu pop-in" ref={ref} role="menu">
        <div className="tool-menu-head">Send the same target to…</div>
        {alts.length === 0 && <div className="tool-menu-empty">No alternative for this input.</div>}
        {alts.map(v => (
          <button key={v.id} className="tool-menu-row" role="menuitem" onClick={() => onPick(v)}>
            <span className="pk-ico"><Icon name={v.icon} size={15} /></span>
            <span className="pk-text"><span className="pk-name">{v.name}</span></span>
            <span className={'pill ' + (v.cls === 'auto' ? 'auto' : 'held')}>{v.cls === 'auto' ? 'Auto' : 'Approval'}</span>
          </button>
        ))}
      </div>
    );
  }

  /* ---- result panel (done) ---- */
  function ResultPanel({ text }) {
    const [open, setOpen] = useState(true);
    const long = text.length > 420;
    return (
      <div className="result-panel">
        <div className="result-head">
          <span className="result-label"><Icon name="doc.text" size={12} /> Result</span>
          <div className="result-tools">
            <button className="link-btn" onClick={() => navigator.clipboard?.writeText(text)}><Icon name="checkmark" size={11} /> Copy</button>
            {long && <button className="link-btn" onClick={() => setOpen(o => !o)}>{open ? 'Collapse' : 'Expand'} <Icon name={open ? 'chevron.up' : 'chevron.down'} size={11} /></button>}
          </div>
        </div>
        <div className={'result-body mono scroll' + (open ? '' : ' clamped')}>{text}</div>
      </div>
    );
  }

  /* ---- the Task Row ---- */
  function TaskRow({ task, onAdvance, onRetry, onChangeTool, onEditRerun, onApprove, onDeny, highlight }) {
    const v = byId[task.verb];
    const [expanded, setExpanded] = useState(task.state === 'done' || task.state === 'failed');
    const [toolOpen, setToolOpen] = useState(false);
    const [editing, setEditing] = useState(false);
    const [editVal, setEditVal] = useState(task.targetFull || task.target || '');
    const title = v.name.replace(/^(\w)/, c => c.toUpperCase());
    const m = STATE_META[task.state];

    return (
      <div className={'task-row ' + m.cls + (highlight ? ' highlight' : '')} data-screen-label={'task ' + task.id}>
        <div className="tr-main" onClick={() => (task.state==='done'||task.state==='failed') && setExpanded(e=>!e)}>
          <span className={'tr-glyph ' + m.cls}><Icon name={task.state==='scheduled'?'calendar':v.icon} size={16} /></span>
          <div className="tr-titles">
            <div className="tr-title">
              {title}{task.target ? <span className="tr-target mono"> — {task.target}</span> : ''}
            </div>
            <div className="tr-sub">
              {task.state === 'working' && <span className="mono">chunk {task.chunk[0]} / {task.chunk[1]}</span>}
              {task.state === 'running' && <span>Started just now</span>}
              {task.state === 'queued' && <span>Waiting to start</span>}
              {task.state === 'scheduled' && <span><Icon name="clock" size={11} /> {clockTime(task.runAt)} · {relTime(task.runAt)}</span>}
              {task.state === 'done' && <span>Completed {clockTime(task.finished || Date.now())}</span>}
              {task.state === 'failed' && <span>Failed {clockTime(task.finished || Date.now())}</span>}
              {task.state === 'held' && <span>{task.hint || 'Needs your approval before running.'}</span>}
            </div>
          </div>
          <div className="tr-right">
            <StateBadge state={task.state} />
            {(task.state==='done'||task.state==='failed') && <span className="tr-chevron"><Icon name={expanded?'chevron.up':'chevron.down'} size={13} /></span>}
          </div>
        </div>

        {task.state === 'working' && (
          <div className="tr-progress"><div className="bar"><i style={{ width: `${Math.round(task.progress*100)}%` }} /></div></div>
        )}
        {task.state === 'running' && (
          <div className="tr-progress"><div className="bar indeterminate"><i /></div></div>
        )}

        {task.state === 'scheduled' && (
          <div className="tr-disclaimer"><Icon name="info" size={13} /> Runs at the set time if your Mac is awake — otherwise on the next wake. Nothing runs while it’s off.</div>
        )}

        {task.state === 'held' && (
          <div className="tr-held">
            <button className="btn small" onClick={() => onDeny(task.id)}>Deny</button>
            <button className="btn small primary consent-ok" onClick={() => onApprove(task.id)}><Icon name="checkmark" size={12} /> Approve &amp; run</button>
          </div>
        )}

        {task.state === 'done' && expanded && <ResultPanel text={task.result} />}

        {task.state === 'failed' && expanded && (
          <div className="tr-fail">
            <div className="fail-msg"><Icon name="xmark.octagon" size={13} /> <span className="mono">{task.error}</span></div>
            {editing ? (
              <div className="path-editor">
                <span className="pe-label">Target</span>
                <input className="pe-input mono" value={editVal} onChange={e=>setEditVal(e.target.value)} spellCheck={false} autoFocus />
                <button className="btn small" onClick={()=>setEditing(false)}>Cancel</button>
                <button className="btn small primary" onClick={()=>{ setEditing(false); onEditRerun(task.id, editVal); }}>Re-run</button>
              </div>
            ) : (
              <div className="fail-actions">
                <button className="btn small" onClick={()=>onRetry(task.id)}><Icon name="refresh" size={12} /> Retry</button>
                <div className="tool-anchor">
                  <button className="btn small" onClick={()=>setToolOpen(o=>!o)}><Icon name="swap" size={12} /> Change tool <Icon name="chevron.down" size={11} /></button>
                  {toolOpen && <ChangeToolMenu task={task} onClose={()=>setToolOpen(false)} onPick={(v)=>{ setToolOpen(false); onChangeTool(task.id, v.id); }} />}
                </div>
                <button className="btn small" onClick={()=>{ setEditing(true); setEditVal(task.targetFull||task.target||''); }}><Icon name="pencil" size={12} /> Edit target</button>
              </div>
            )}
          </div>
        )}
      </div>
    );
  }

  /* ---- empty states ---- */
  function Empty({ icon, title, sub }) {
    return (
      <div className="board-empty fade-in">
        <div className="board-empty-glyph"><Icon name={icon} size={24} /></div>
        <div className="board-empty-title">{title}</div>
        {sub && <div className="board-empty-sub">{sub}</div>}
      </div>
    );
  }

  /* ---- scheduling presets (shown atop Scheduled) ---- */
  function SchedulePresets() {
    return (
      <div className="sched-presets">
        <span className="sched-presets-label">Quick schedule</span>
        <div className="preset-set" role="group" aria-label="Schedule presets">
          {['Tonight 2 AM', 'In 1 hour', 'In 4 hours'].map((p, i) => (
            <button key={p} className={'preset' + (i===0?' on':'')}>{p}</button>
          ))}
        </div>
      </div>
    );
  }

  function CanvasTab({ tasks, sub, setSub, highlightId, ...handlers }) {
    const now = tasks.filter(t => ['queued','running','working'].includes(t.state));
    const scheduled = tasks.filter(t => t.state === 'scheduled').sort((a,b)=>a.runAt-b.runAt);
    const finished = tasks.filter(t => ['done','failed'].includes(t.state));
    const held = tasks.filter(t => t.state === 'held');

    const SUBS = [
      { id: 'now', label: 'Now', count: now.length },
      { id: 'scheduled', label: 'Scheduled', count: scheduled.length },
      { id: 'activity', label: 'Activity', count: finished.length + held.length },
    ];

    return (
      <div className="canvas-tab">
        <div className="canvas-head">
          <div className="segmented" role="tablist">
            {SUBS.map(s => (
              <button key={s.id} role="tab" aria-selected={sub===s.id}
                className={'seg' + (sub===s.id?' on':'')} onClick={()=>setSub(s.id)}>
                {s.label}{s.count>0 && <span className="seg-count">{s.count}</span>}
              </button>
            ))}
          </div>
          {sub === 'activity' && finished.length > 0 && (
            <button className="btn small" onClick={handlers.onClearCompleted}><Icon name="eraser" size={12} /> Clear completed</button>
          )}
        </div>

        <div className="board scroll">
          {sub === 'now' && (
            now.length === 0
              ? <Empty icon="play" title="Nothing running." sub="Start a job from Chat and watch it here." />
              : <div className="rows">{now.map(t => <TaskRow key={t.id} task={t} highlight={t.id===highlightId} {...handlers} />)}</div>
          )}

          {sub === 'scheduled' && (
            <div>
              <SchedulePresets />
              {scheduled.length === 0
                ? <Empty icon="calendar" title="Nothing scheduled." />
                : <div className="rows">{scheduled.map(t => <TaskRow key={t.id} task={t} highlight={t.id===highlightId} {...handlers} />)}</div>}
            </div>
          )}

          {sub === 'activity' && (
            (finished.length + held.length) === 0
              ? <Empty icon="checkmark.circle" title="No finished tasks yet." />
              : <div className="rows">
                  {held.length > 0 && <div className="sec-head board-sec">Held for approval</div>}
                  {held.map(t => <TaskRow key={t.id} task={t} highlight={t.id===highlightId} {...handlers} />)}
                  {finished.length > 0 && <div className="sec-head board-sec">Completed &amp; failed</div>}
                  {finished.map(t => <TaskRow key={t.id} task={t} highlight={t.id===highlightId} {...handlers} />)}
                </div>
          )}
        </div>
      </div>
    );
  }

  window.CanvasTab = CanvasTab;
})();
