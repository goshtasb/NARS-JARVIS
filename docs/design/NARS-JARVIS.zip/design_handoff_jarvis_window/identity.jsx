/* identity.jsx — Tab 3: Cognitive Identity (the passive mirror + learned habits). */
(function () {
  const { useState } = React;
  const { MIRROR, HABITS, PERSONA, fmtMins } = window.JARVIS;
  const Icon = window.Icon;

  const KIND_COLOR = {
    development: 'var(--blue-solid)',
    communication: 'var(--amber-solid)',
    media: 'var(--green-solid)',
    other: 'var(--label-3)',
  };

  function MirrorCard({ data }) {
    const total = data.apps.reduce((s, a) => s + a.mins, 0);
    const max = Math.max(...data.apps.map(a => a.mins));
    return (
      <div className="mirror-card fade-in">
        <div className="mirror-top">
          <div>
            <div className="mirror-title">What I’ve noticed about your computer use</div>
            <div className="mirror-meta">{data.windowHours} hours · {data.switches} app switches</div>
          </div>
          <span className="mirror-glyph"><Icon name="eye" size={16} /></span>
        </div>

        <div className="mirror-block">
          <div className="mirror-block-label">Most of your time</div>
          <div className="mirror-bars">
            {data.apps.map(a => (
              <div className="mb-row" key={a.name}>
                <span className="mb-name">{a.name}</span>
                <span className="mb-track"><i style={{ width: `${(a.mins/max)*100}%`, background: KIND_COLOR[a.kind] || KIND_COLOR.other }} /></span>
                <span className="mb-val mono">{fmtMins(a.mins)}</span>
              </div>
            ))}
          </div>
        </div>

        <div className="mirror-row2">
          <div className="mirror-block">
            <div className="mirror-block-label">By kind</div>
            <div className="kind-chips">
              {data.kinds.map(k => (
                <span className="kind-chip" key={k}><span className="kind-dot" style={{ background: KIND_COLOR[k] }} />{k}</span>
              ))}
            </div>
          </div>
          <div className="mirror-block">
            <div className="mirror-block-label">Busiest around</div>
            <div className="busiest"><Icon name="clock" size={14} /> {data.busiest}</div>
          </div>
        </div>

        <div className="privacy-line">
          <Icon name="eye.slash" size={13} />
          Learned from which app is in front — never your screen contents.
        </div>
      </div>
    );
  }

  function MirrorLearning() {
    return (
      <div className="mirror-card learning fade-in">
        <div className="mirror-learning-inner">
          <span className="mirror-glyph big"><Icon name="sparkle" size={20} /></span>
          <div className="mirror-title">Still learning</div>
          <div className="mirror-learning-sub">Give me a couple more days of normal use and I’ll show you the patterns I notice.</div>
          <div className="privacy-line center"><Icon name="eye.slash" size={13} /> Learned from which app is in front — never your screen contents.</div>
        </div>
      </div>
    );
  }

  function HabitRow({ item, onForget }) {
    const [confirm, setConfirm] = useState(false);
    return (
      <div className="habit-row">
        <span className={'state-tag ' + item.state}>{item.state === 'active' ? 'Active' : 'Learning'}</span>
        <span className="habit-text">{item.text}</span>
        {confirm ? (
          <span className="forget-confirm">
            <span className="fc-q">Forget this?</span>
            <button className="btn small" onClick={() => setConfirm(false)}>Keep</button>
            <button className="btn small destructive" onClick={() => onForget(item.id)}>Forget</button>
          </span>
        ) : (
          <button className="forget-btn" onClick={() => setConfirm(true)}><Icon name="eraser" size={12} /> Forget</button>
        )}
      </div>
    );
  }

  function PersonaRow({ item, onForget }) {
    const [confirm, setConfirm] = useState(false);
    return (
      <div className="habit-row persona">
        <span className="persona-dot" />
        <span className="habit-text">{item.text}</span>
        {confirm ? (
          <span className="forget-confirm">
            <span className="fc-q">Forget this?</span>
            <button className="btn small" onClick={() => setConfirm(false)}>Keep</button>
            <button className="btn small destructive" onClick={() => onForget(item.id)}>Forget</button>
          </span>
        ) : (
          <button className="forget-btn" onClick={() => setConfirm(true)}><Icon name="eraser" size={12} /> Forget</button>
        )}
      </div>
    );
  }

  function IdentityTab({ connected }) {
    const [habits, setHabits] = useState(HABITS);
    const [persona, setPersona] = useState(PERSONA);
    const [refreshing, setRefreshing] = useState(false);
    function refresh() { setRefreshing(true); setTimeout(() => setRefreshing(false), 900); }

    if (!connected) {
      return (
        <div className="identity-tab">
          <div className="board-empty fade-in">
            <div className="board-empty-glyph"><Icon name="bolt" size={24} /></div>
            <div className="board-empty-title">Disconnected</div>
            <div className="board-empty-sub">Reconnecting to the engine — your learned profile will appear here.</div>
          </div>
        </div>
      );
    }

    return (
      <div className="identity-tab scroll">
        <div className="identity-inner">
          <div className="id-headrow">
            <div className="id-head-title">Cognitive Identity</div>
            <button className={'btn small' + (refreshing ? ' is-refreshing' : '')} onClick={refresh}>
              <Icon name="refresh" size={12} /> {refreshing ? 'Refreshing…' : 'Refresh'}
            </button>
          </div>

          <MirrorCard data={MIRROR} />

          <div className="id-section">
            <div className="sec-head">Learned habits</div>
            <div className="id-list">
              {habits.length === 0
                ? <div className="id-empty">No habits yet — I’m still learning your rhythm.</div>
                : habits.map(h => <HabitRow key={h.id} item={h} onForget={(id)=>setHabits(hs=>hs.filter(x=>x.id!==id))} />)}
            </div>
          </div>

          <div className="id-section">
            <div className="sec-head">Style &amp; preferences</div>
            <div className="id-sub">Plain-English things I’ve inferred about how you like to work.</div>
            <div className="id-list">
              {persona.length === 0
                ? <div className="id-empty">Nothing inferred yet.</div>
                : persona.map(p => <PersonaRow key={p.id} item={p} onForget={(id)=>setPersona(ps=>ps.filter(x=>x.id!==id))} />)}
            </div>
          </div>
        </div>
      </div>
    );
  }

  window.IdentityTab = IdentityTab;
})();
