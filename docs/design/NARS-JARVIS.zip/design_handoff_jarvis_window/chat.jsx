/* chat.jsx — Tab 1: the Universal Composer (conversation + command bar). */
(function () {
  const { useState, useRef, useEffect, useLayoutEffect } = React;
  const { CATALOG, byId, filterVerbs, parseJob, relTime, clockTime } = window.JARVIS;
  const Icon = window.Icon;

  /* ---------- live task status chip (in the transcript) ---------- */
  function LiveChip({ task, onView }) {
    if (!task) return null;
    const v = byId[task.verb];
    const label = v.name.replace(/^(\w)/, (c) => c.toUpperCase());
    const tgt = task.target ? ` (${task.target})` : '';
    let body;
    if (task.state === 'queued') body = <span className="chip-state"><Icon name="hourglass" size={12} /> queued</span>;
    else if (task.state === 'running') body = <span className="chip-state"><span className="spinner"><i style={{transform:'rotate(0deg)'}}/><i style={{transform:'rotate(90deg)'}}/><i style={{transform:'rotate(180deg)'}}/><i style={{transform:'rotate(270deg)'}}/></span> working…</span>;
    else if (task.state === 'working') body = (
      <span className="chip-work">
        <span className="chip-state">working</span>
        <span className="chip-bar"><i style={{ width: `${Math.round(task.progress*100)}%` }} /></span>
        <span className="mono chip-chunk">chunk {task.chunk[0]}/{task.chunk[1]}</span>
      </span>
    );
    else if (task.state === 'done') body = <span className="chip-state done"><Icon name="checkmark.circle" size={13} /> done</span>;
    else if (task.state === 'failed') body = <span className="chip-state failed"><Icon name="xmark.octagon" size={13} /> failed</span>;
    else if (task.state === 'scheduled') body = <span className="chip-state sched"><Icon name="calendar" size={12} /> scheduled for {clockTime(task.runAt)}</span>;
    const cls = 'live-chip ' + task.state;
    return (
      <div className={cls + ' pop-in'} role="status">
        <span className={'chip-glyph ' + task.state}><Icon name={task.state==='scheduled'?'calendar':v.icon} size={14} /></span>
        <span className="chip-title">{label}{tgt}</span>
        <span className="chip-divider" />
        {body}
        <button className="chip-view" onClick={() => onView(task.id)}>
          View on Canvas <Icon name="chevron.right" size={11} />
        </button>
      </div>
    );
  }

  /* ---------- transcript message rows ---------- */
  function MessageRow({ m, task, onView }) {
    if (m.kind === 'chip') return <div className="row-wrap left"><LiveChip task={task} onView={onView} /></div>;
    if (m.kind === 'user') return (
      <div className="row-wrap right"><div className="bubble user fade-in">{m.text}</div></div>
    );
    if (m.kind === 'voice') return (
      <div className="row-wrap right">
        <div className="bubble user voice fade-in"><Icon name="waveform" size={13} /><span>{m.text}</span></div>
      </div>
    );
    if (m.kind === 'assistant') return (
      <div className="row-wrap left"><div className="bubble assistant fade-in">{m.text}</div></div>
    );
    if (m.kind === 'saved') return (
      <div className="row-wrap left"><div className="sys-line saved fade-in"><Icon name="checkmark" size={13} /><span>{m.text}</span></div></div>
    );
    if (m.kind === 'alert') return (
      <div className="row-wrap left"><div className="sys-card alert fade-in"><span className="sys-ico"><Icon name="info" size={14} /></span><div><div className="sys-card-title">Sentinel notice</div><div className="sys-card-body">{m.text}</div></div></div></div>
    );
    if (m.kind === 'error') return (
      <div className="row-wrap left"><div className="sys-card error fade-in"><span className="sys-ico"><Icon name="xmark.octagon" size={14} /></span><div className="sys-card-body">{m.text}</div></div></div>
    );
    return null;
  }

  /* ---------- the / action-picker overlay ---------- */
  function ActionPicker({ query, onPick, onClose, anchorUp }) {
    const results = filterVerbs(query);
    const [sel, setSel] = useState(0);
    const listRef = useRef(null);
    useEffect(() => { setSel(0); }, [query]);
    useEffect(() => {
      const h = (e) => {
        if (e.key === 'ArrowDown') { e.preventDefault(); setSel(s => Math.min(results.length - 1, s + 1)); }
        else if (e.key === 'ArrowUp') { e.preventDefault(); setSel(s => Math.max(0, s - 1)); }
        else if (e.key === 'Enter') { if (results[sel]) { e.preventDefault(); onPick(results[sel]); } }
        else if (e.key === 'Escape') { e.preventDefault(); onClose(); }
      };
      window.addEventListener('keydown', h, true);
      return () => window.removeEventListener('keydown', h, true);
    }, [results, sel, onPick, onClose]);
    useLayoutEffect(() => {
      const el = listRef.current?.querySelector('.pk-row.sel');
      if (el) el.scrollIntoView ? null : null; // avoid scrollIntoView; manual:
      if (el && listRef.current) {
        const c = listRef.current, r = el;
        if (r.offsetTop < c.scrollTop) c.scrollTop = r.offsetTop;
        else if (r.offsetTop + r.offsetHeight > c.scrollTop + c.clientHeight)
          c.scrollTop = r.offsetTop + r.offsetHeight - c.clientHeight;
      }
    }, [sel]);
    return (
      <div className={'picker pop-in ' + (anchorUp ? 'up' : 'down')} role="listbox" aria-label="Actions">
        <div className="pk-head">
          <Icon name="slash" size={12} />
          <span>{query ? `Actions matching “${query}”` : 'Run a job — pick an action'}</span>
        </div>
        <div className="pk-list scroll" ref={listRef}>
          {results.length === 0 && (
            <div className="pk-empty">
              <Icon name="search" size={20} />
              <div>No actions match “{query}”.</div>
              <div className="pk-empty-sub">Try “summarize”, “network”, or “open”.</div>
            </div>
          )}
          {results.map((v, i) => (
            <button key={v.id} className={'pk-row' + (i === sel ? ' sel' : '')}
              role="option" aria-selected={i === sel}
              onMouseEnter={() => setSel(i)} onClick={() => onPick(v)}>
              <span className="pk-ico"><Icon name={v.icon} size={16} /></span>
              <span className="pk-text">
                <span className="pk-name">{v.name}</span>
                <span className="pk-desc">{v.desc}</span>
              </span>
              <span className={'pill ' + (v.cls === 'auto' ? 'auto' : 'held')}>
                {v.cls === 'auto'
                  ? <><Icon name="bolt" size={10} /> Auto</>
                  : <><Icon name="pause" size={10} /> Needs approval</>}
              </span>
            </button>
          ))}
        </div>
        <div className="pk-foot">
          <span><kbd>↑</kbd><kbd>↓</kbd> navigate</span>
          <span><kbd>↵</kbd> choose</span>
          <span><kbd>esc</kbd> dismiss</span>
        </div>
      </div>
    );
  }

  /* ---------- attachment chip ---------- */
  function AttachChip({ file, onRemove }) {
    return (
      <span className="attach-chip">
        <Icon name="doc" size={12} />
        <span className="attach-name">{file}</span>
        <button className="attach-x" onClick={onRemove} aria-label="Remove attachment"><Icon name="xmark.small" size={11} /></button>
      </span>
    );
  }

  /* ---------- inline consent bar ---------- */
  function ConsentBar({ verb, onApprove, onDeny }) {
    return (
      <div className="consent-bar pop-in" role="alertdialog">
        <span className="consent-ico"><Icon name="pause" size={15} /></span>
        <div className="consent-text">
          <b>{verb.name}</b> needs your approval — it can change your system. {verb.id === 'emptytrash' ? 'This permanently deletes trashed items.' : ''}
        </div>
        <div className="consent-actions">
          <button className="btn small" onClick={onDeny}>Deny</button>
          <button className="btn small primary consent-ok" onClick={onApprove}><Icon name="checkmark" size={12} /> Approve</button>
        </div>
      </div>
    );
  }

  const SAMPLE_FILES = ['Q3-PRD.pdf', 'weekly-notes.md', 'budget.xlsx', 'design-brief.txt'];

  /* ---------- input bar ---------- */
  function InputBar({ connected, onSubmit, voice, onToggleVoice }) {
    const [text, setText] = useState('');
    const [pinned, setPinned] = useState(null);    // verb object
    const [attach, setAttach] = useState(null);     // filename
    const [pickerOpen, setPickerOpen] = useState(false);
    const [attachMenu, setAttachMenu] = useState(false);
    const taRef = useRef(null);
    const disabled = !connected;

    const pickerQuery = pickerOpen ? (text.startsWith('/') ? text.slice(1) : '') : '';

    useEffect(() => { autosize(); }, [text]);
    function autosize() { const t = taRef.current; if (!t) return; t.style.height = 'auto'; t.style.height = Math.min(96, t.scrollHeight) + 'px'; }

    function onChange(e) {
      const val = e.target.value;
      if (!pinned && val.startsWith('/')) { setPickerOpen(true); setText(val); return; }
      if (pickerOpen && !val.startsWith('/')) setPickerOpen(false);
      setText(val);
    }
    function onKey(e) {
      if (e.key === 'Escape') { setPickerOpen(false); setAttachMenu(false); return; }
      if (e.key === '/' && !pinned && (text === '' )) { /* opens via onChange */ }
      if (e.key === 'Backspace' && pinned && taRef.current.selectionStart === 0) { setPinned(null); return; }
      if (e.key === 'Enter' && !e.shiftKey && !pickerOpen) { e.preventDefault(); submit(); }
    }
    function pickVerb(v) { setPinned(v); setText(''); setPickerOpen(false); setTimeout(() => taRef.current?.focus(), 0); }
    function submit() {
      if (disabled) return;
      const body = text.trim();
      if (pinned) {
        onSubmit({ type: 'job', verb: pinned, rest: body, attach });
        setPinned(null); setText(''); setAttach(null);
      } else if (body) {
        onSubmit({ type: 'chat', text: body, attach });
        setText(''); setAttach(null);
      }
    }

    return (
      <div className="composer">
        {pickerOpen && (
          <ActionPicker query={pickerQuery} anchorUp
            onPick={pickVerb} onClose={() => { setPickerOpen(false); if (text === '/') setText(''); }} />
        )}
        {attachMenu && (
          <div className="attach-menu pop-in" onMouseLeave={() => setAttachMenu(false)}>
            <div className="attach-menu-head">Choose a file…</div>
            {SAMPLE_FILES.map(f => (
              <button key={f} className="attach-menu-row" onClick={() => { setAttach(f); setAttachMenu(false); }}>
                <Icon name="doc" size={14} /> {f}
              </button>
            ))}
          </div>
        )}
        <div className={'input-bar' + (disabled ? ' disabled' : '')}>
          <button className="input-ctl" disabled={disabled} title="Attach a file"
            onClick={() => setAttachMenu(m => !m)} aria-label="Attach a file (+)">
            <Icon name="plus" size={17} />
          </button>
          <button className={'input-ctl' + (pickerOpen ? ' on' : '')} disabled={disabled} title="Run a job"
            onClick={() => { setPickerOpen(o => !o); taRef.current?.focus(); }} aria-label="Action picker (/)">
            <Icon name="slash" size={16} />
          </button>

          <div className="input-field">
            {pinned && (
              <span className="verb-token">
                <Icon name={pinned.icon} size={12} />
                <span>{pinned.name}</span>
                <span className={'pill ' + (pinned.cls === 'auto' ? 'auto' : 'held')} style={{ height: 15, fontSize: 9.5 }}>
                  {pinned.cls === 'auto' ? 'Auto' : 'Approval'}
                </span>
              </span>
            )}
            {attach && !pinned && <AttachChip file={attach} onRemove={() => setAttach(null)} />}
            <textarea ref={taRef} rows={1} value={text}
              disabled={disabled}
              onChange={onChange} onKeyDown={onKey}
              placeholder={pinned ? 'Add the target and timing… e.g. the PRD on my desktop tonight' : (disabled ? 'Reconnecting to the engine…' : 'Ask, or type / to run a job…')} />
            {attach && pinned && <AttachChip file={attach} onRemove={() => setAttach(null)} />}
          </div>

          <button className={'input-ctl mic' + (voice ? ' rec' : '')} disabled={disabled}
            onClick={onToggleVoice} title={voice ? 'Stop & send' : 'Listen'} aria-label={voice ? 'Stop and send' : 'Push to talk'}>
            <Icon name="mic" size={16} />
            {voice && <span className="mic-ring" />}
          </button>
          <button className="send-btn" disabled={disabled || (!text.trim() && !pinned)} onClick={submit} aria-label="Send">
            <Icon name="arrow.up" size={16} />
          </button>
        </div>
        {voice && <div className="voice-hint"><span className="rec-dot" /> Listening… <span className="mono">0:06 / 0:30</span> — tap the mic to stop &amp; send</div>}
      </div>
    );
  }

  /* ---------- empty state ---------- */
  function ChatEmpty() {
    return (
      <div className="chat-empty fade-in">
        <div className="chat-empty-glyph"><Icon name="sparkle" size={26} /></div>
        <div className="chat-empty-title">What can I do?</div>
        <div className="chat-empty-sub">Ask me something, or type <span className="kbd-inline">/</span> to run a job.</div>
        <div className="chat-empty-chips">
          {['Summarize a document','System report','What\u2019s slowing my internet?'].map(s => (
            <span key={s} className="suggest-chip">{s}</span>
          ))}
        </div>
      </div>
    );
  }

  /* ---------- the tab ---------- */
  function ChatTab({ connected, messages, tasks, consent, onSubmit, onViewOnCanvas, onConsent, voice, onToggleVoice }) {
    const logRef = useRef(null);
    useLayoutEffect(() => {
      const el = logRef.current; if (el) el.scrollTop = el.scrollHeight;
    }, [messages, tasks, consent]);
    const taskById = Object.fromEntries(tasks.map(t => [t.id, t]));
    return (
      <div className="chat-tab">
        <div className="chat-log scroll" ref={logRef}>
          {messages.length === 0 ? <ChatEmpty /> : (
            <div className="log-inner">
              {messages.map(m => (
                <MessageRow key={m.id} m={m} task={m.kind === 'chip' ? taskById[m.taskId] : null} onView={onViewOnCanvas} />
              ))}
            </div>
          )}
        </div>
        <div className="composer-zone">
          {consent && <ConsentBar verb={consent} onApprove={() => onConsent(true)} onDeny={() => onConsent(false)} />}
          {!connected && (
            <div className="disconnect-bar"><span className="conn-dot" style={{ background: 'var(--amber-solid)' }} /> Disconnected from the engine — reconnecting. Composing is paused.</div>
          )}
          <InputBar connected={connected} onSubmit={onSubmit} voice={voice} onToggleVoice={onToggleVoice} />
        </div>
      </div>
    );
  }

  window.ChatTab = ChatTab;
})();
