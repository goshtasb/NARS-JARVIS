/* icons.jsx — SF-Symbol-style monoline icons (24px grid, currentColor).
   Each entry is documented with its SF Symbol name for native handoff. */
(function () {
  const P = {
    // ---- tabs ----
    chat: '<path d="M4.5 5.5h12a2 2 0 0 1 2 2v6a2 2 0 0 1-2 2H10l-4 3v-3H4.5a2 2 0 0 1-2-2v-6a2 2 0 0 1 2-2Z"/>', // message
    canvas: '<rect x="3.5" y="3.5" width="7" height="7" rx="1.6"/><rect x="13.5" y="3.5" width="7" height="7" rx="1.6"/><rect x="3.5" y="13.5" width="7" height="7" rx="1.6"/><rect x="13.5" y="13.5" width="7" height="7" rx="1.6"/>', // square.grid.2x2
    identity: '<path d="M12 13.2c2.2 0 3.7-1.9 3.7-4.3S14.2 4.7 12 4.7 8.3 6.5 8.3 8.9s1.5 4.3 3.7 4.3Z"/><path d="M5 19.4c.7-3 3.5-4.4 7-4.4s6.3 1.4 7 4.4"/>', // person.crop.circle

    // ---- verbs (action catalog) ----
    'doc.text': '<path d="M6 3.5h7l5 5v12a0 0 0 0 1 0 0H6a0 0 0 0 1 0 0V3.5Z"/><path d="M13 3.5V8.5h5"/><path d="M8.5 12.5h7M8.5 15.5h7M8.5 18h4"/>', // summarize a document
    globe: '<circle cx="12" cy="12" r="8.2"/><path d="M3.8 12h16.4M12 3.8c2.4 2.2 2.4 14.2 0 16.4M12 3.8c-2.4 2.2-2.4 14.2 0 16.4"/>', // read a web article
    doc: '<path d="M6 3.5h7l5 5v12H6V3.5Z"/><path d="M13 3.5V8.5h5"/>', // read a file
    search: '<circle cx="11" cy="11" r="6.4"/><path d="M15.8 15.8 20 20"/>', // web search
    gauge: '<path d="M4 17a8 8 0 1 1 16 0"/><path d="M12 17l4-5"/><circle cx="12" cy="17" r="1.3" fill="currentColor" stroke="none"/>', // system report
    speaker: '<path d="M4.5 9.5h3l4-3.5v12l-4-3.5h-3v-5Z"/><path d="M14.5 9c1 .9 1 4.1 0 5M16.7 7c2 1.7 2 8.3 0 10"/>', // audio status / set volume
    'speaker.slash': '<path d="M4.5 9.5h3l4-3.5v12l-4-3.5h-3v-5Z"/><path d="M15 9.5 20 14.5M20 9.5 15 14.5"/>', // mute
    wifi: '<path d="M3 9.5c5.2-4.3 12.8-4.3 18 0M6 13c3.6-2.9 8.4-2.9 12 0M9 16.4c1.8-1.4 4.2-1.4 6 0"/><circle cx="12" cy="19.5" r="1.2" fill="currentColor" stroke="none"/>', // network status
    chart: '<path d="M4 20V10M9.3 20V5M14.6 20v-8M20 20V8"/>', // largest apps
    'doc.search': '<path d="M6 3.5h7l5 5v6"/><path d="M13 3.5V8.5h5"/><path d="M6 3.5v17h6"/><circle cx="16.2" cy="17.2" r="3"/><path d="M18.4 19.4 21 22"/>', // find a file
    app: '<rect x="4" y="4" width="16" height="16" rx="3.4" stroke-dasharray="2.4 2.6"/><path d="M9 12h6M12 9v6"/>', // open an app
    link: '<path d="M10 14a3.5 3.5 0 0 0 5 0l3-3a3.5 3.5 0 0 0-5-5l-1 1"/><path d="M14 10a3.5 3.5 0 0 0-5 0l-3 3a3.5 3.5 0 0 0 5 5l1-1"/>', // open a URL
    trash: '<path d="M5.5 6.5h13M9 6.5V5a1.5 1.5 0 0 1 1.5-1.5h3A1.5 1.5 0 0 1 15 5v1.5M7 6.5l.8 12.2a1.5 1.5 0 0 0 1.5 1.4h5.4a1.5 1.5 0 0 0 1.5-1.4L17 6.5"/>', // empty trash

    // ---- states ----
    hourglass: '<path d="M7 4.5h10M7 19.5h10M8 4.5c0 4 8 4 8 8s-8 4-8 8M16 4.5c0 4-8 4-8 8s8 4 8 8"/>', // queued
    play: '<path d="M8 5.5v13l11-6.5-11-6.5Z"/>', // running
    'checkmark.circle': '<circle cx="12" cy="12" r="8.4"/><path d="M8.2 12.2l2.7 2.7 5-5.4"/>', // done
    'xmark.octagon': '<path d="M8.2 3.8h7.6l5.4 5.4v7.6l-5.4 5.4H8.2L2.8 16.8V9.2L8.2 3.8Z"/><path d="M9.2 9.2l5.6 5.6M14.8 9.2l-5.6 5.6"/>', // failed
    pause: '<circle cx="12" cy="12" r="8.4"/><path d="M10 9v6M14 9v6"/>', // held
    calendar: '<rect x="3.8" y="5" width="16.4" height="15" rx="2.2"/><path d="M3.8 9.5h16.4M8 3.2v3.6M16 3.2v3.6"/>', // scheduled

    // ---- controls ----
    plus: '<path d="M12 5v14M5 12h14"/>',
    slash: '<path d="M15 4.5 9 19.5"/>',
    mic: '<rect x="9" y="3.2" width="6" height="11" rx="3"/><path d="M5.5 11.5a6.5 6.5 0 0 0 13 0M12 18v3M9 21h6"/>',
    'arrow.up': '<path d="M12 19V5M6 11l6-6 6 6"/>',
    paperclip: '<path d="M17.5 9.5l-7 7a3 3 0 0 1-4.2-4.2l8-8a4.5 4.5 0 0 1 6.4 6.4l-8 8"/>',
    xmark: '<path d="M6 6l12 12M18 6 6 18"/>',
    'xmark.small': '<path d="M7 7l10 10M17 7 7 17"/>',
    refresh: '<path d="M19 8a8 8 0 1 0 1.5 6"/><path d="M20 3v5h-5"/>',
    'chevron.down': '<path d="M5 9l7 7 7-7"/>',
    'chevron.right': '<path d="M9 5l7 7-7 7"/>',
    'chevron.up': '<path d="M5 15l7-7 7 7"/>',
    bolt: '<path d="M13 2.5 4.5 13.5H11l-1 8L19 10.5h-6.5l.5-8Z"/>',
    stop: '<circle cx="12" cy="12" r="8.6"/><rect x="9" y="9" width="6" height="6" rx="1.3"/>',
    eye: '<path d="M2.6 12S6 5.5 12 5.5 21.4 12 21.4 12 18 18.5 12 18.5 2.6 12 2.6 12Z"/><circle cx="12" cy="12" r="2.6"/>',
    'eye.slash': '<path d="M4 4l16 16M9.6 6C10.4 5.7 11.2 5.5 12 5.5c6 0 9.4 6.5 9.4 6.5a16 16 0 0 1-3 3.6M6.3 8.2A16 16 0 0 0 2.6 12S6 18.5 12 18.5c1 0 1.9-.2 2.7-.5"/>',
    clock: '<circle cx="12" cy="12" r="8.4"/><path d="M12 7.5V12l3 2"/>',
    sun: '<circle cx="12" cy="12" r="4.2"/><path d="M12 2.5v2.4M12 19.1v2.4M4.6 4.6l1.7 1.7M17.7 17.7l1.7 1.7M2.5 12h2.4M19.1 12h2.4M4.6 19.4l1.7-1.7M17.7 6.3l1.7-1.7"/>',
    moon: '<path d="M19 14.5A8 8 0 0 1 9.5 5 7 7 0 1 0 19 14.5Z"/>',
    'arrow.right.circle': '<circle cx="12" cy="12" r="8.4"/><path d="M8.5 12h7M12.5 9l3 3-3 3"/>',
    swap: '<path d="M5 8h12l-3-3M19 16H7l3 3"/>',
    pencil: '<path d="M14.5 5.5l4 4M4 20l1-4L16 5a1.4 1.4 0 0 1 2 0l1 1a1.4 1.4 0 0 1 0 2L8 19l-4 1Z"/>',
    sparkle: '<path d="M12 3l1.8 5.4L19 10l-5.2 1.6L12 17l-1.8-5.4L5 10l5.2-1.6L12 3Z"/>',
    info: '<circle cx="12" cy="12" r="8.4"/><path d="M12 11v5M12 7.6v.6" stroke-width="1.8"/>',
    'checkmark': '<path d="M5 12.5l4.5 4.5L19 7"/>',
    waveform: '<path d="M3 12h2M7 8v8M11 4.5v15M15 8v8M19 11h2"/>',
    eraser: '<path d="M8 18.5h12M5 14l5.5-5.5a1.6 1.6 0 0 1 2.3 0l4.2 4.2a1.6 1.6 0 0 1 0 2.3l-3.5 3.5H8.5L5 15a0 0 0 0 1 0-1Z"/>',
  };

  function Icon({ name, size = 18, strokeWidth = 1.5, style, className }) {
    const d = P[name];
    if (!d) return null;
    const filled = name === 'play';
    return React.createElement('svg', {
      width: size, height: size, viewBox: '0 0 24 24',
      fill: filled ? 'currentColor' : 'none',
      stroke: filled ? 'none' : 'currentColor',
      strokeWidth, strokeLinecap: 'round', strokeLinejoin: 'round',
      style, className,
      dangerouslySetInnerHTML: { __html: d },
    });
  }

  window.Icon = Icon;
  window.ICON_NAMES = Object.keys(P);
})();
