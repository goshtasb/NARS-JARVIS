/* app.jsx — window shell, toolbar, global state, task state-machine runner. */
(function () {
  const { useState, useRef, useEffect, useCallback } = React;
  const { byId, seedTasks, parseJob, clockTime, SUMMARY_RESULT } = window.JARVIS;
  const Icon = window.Icon;

  // canned results per verb
  const RESULTS = {
    summarize: SUMMARY_RESULT,
    readfile: 'weekly-notes.md (1,240 words)\n\nThe file is your running notes for the week. It opens with three priorities, then a log of meetings, then a short list of follow-ups. No headings beyond the date markers; mostly bullet points.',
    readweb: 'Article — “Local-first software” (read-time ~9 min)\n\nThe piece argues for keeping data on the user’s device while preserving collaboration. Seven ideals are listed: fast, multi-device, offline, collaborative, long-lived, private, and user-controlled. It closes with open research questions around sync.',
    websearch: 'Top results for your query:\n1. Local-first software — the seven ideals (essay)\n2. CRDTs explained — a gentle introduction\n3. Building offline-first Mac apps with SwiftData',
    sysreport: 'System report — this Mac\n\u2022 CPU: 14% avg over the last minute\n\u2022 Memory: 11.2 GB used of 16 GB (3 GB cached)\n\u2022 Disk: 312 GB free of 994 GB\n\u2022 Uptime: 2 days, 4 hours\n\u2022 Battery: 88% (not charging)\nNothing looks unhealthy right now.',
    audio: 'Output: MacBook Pro Speakers · Volume 32% · Not muted.\nInput: MacBook Pro Microphone.',
    network: 'Wi-Fi connected to “Studio” · 5 GHz · −52 dBm (strong)\nDown 318 Mbps / Up 41 Mbps · 14 ms latency\nNo throttling detected. The slowdown earlier was a brief DNS stall, now cleared.',
    largest: 'Largest apps by disk:\n1. Xcode — 38.4 GB\n2. Docker — 6.1 GB\n3. Chrome — 1.9 GB\n4. Music (cache) — 1.2 GB',
    findfile: 'Found 1 match:\n/Users/me/Desktop/Q3-PRD.pdf (2.1 MB, modified today)',
    openapp: 'Opened Terminal.',
    openurl: 'Opened the link in your browser.',
    setvolume: 'Set output volume to 40%.',
    mute: 'System audio muted.',
    emptytrash: 'Trash emptied — 1.4 GB reclaimed.',
  };

  const CHUNKED = new Set(['summarize', 'readfile', 'readweb', 'websearch']);

  function StopModal({ onCancel, onConfirm }) {
    return (
      <div className="modal-scrim" onClick={onCancel}>
        <div className="stop-modal pop-in" onClick={e=>e.stopPropagation()} role="alertdialog" aria-modal="true">
          <div className="stop-modal-ico"><Icon name="stop" size={26} /></div>
          <div className="stop-modal-title">Stop everything?</div>
          <div className="stop-modal-body">This halts the assistant and cancels every running and scheduled job. You can reopen JARVIS from the menu bar afterwards.</div>
          <div className="stop-modal-actions">
            <button className="btn" onClick={onCancel}>Cancel</button>
            <button className="btn destructive" onClick={onConfirm}><Icon name="stop" size={13} /> Stop everything</button>
          </div>
        </div>
      </div>
    );
  }

  function App() {
    const [theme, setTheme] = useState('light');
    const [tab, setTab] = useState('chat');
    const [sub, setSub] = useState('now');
    const [connected, setConnected] = useState(true);
    const [tasks, setTasks] = useState(seedTasks);
    const [messages, setMessages] = useState([]);
    const [consent, setConsent] = useState(null);     // {verb, rest, attach}
    const [voice, setVoice] = useState(false);
    const [highlightId, setHighlightId] = useState(null);
    const [stopOpen, setStopOpen] = useState(false);
    const timers = useRef([]);
    const idc = useRef(100);
    const consentTimer = useRef(null);
    const voiceTimer = useRef(null);

    const track = (t) => { timers.current.push(t); return t; };
    const clearTimers = () => { timers.current.forEach(clearTimeout); timers.current = []; };
    const nid = (p) => `${p}${++idc.current}`;
    const updateTask = (id, patch) => setTasks(ts => ts.map(t => t.id === id ? { ...t, ...patch } : t));
    const pushMsg = (m) => setMessages(ms => [...ms, { id: nid('m'), ...m }]);

    const activeCount = tasks.filter(t => ['running','working','queued'].includes(t.state)).length;

    // keep relative countdowns fresh
    const [, force] = useState(0);
    useEffect(() => { const i = setInterval(() => force(x => x + 1), 30000); return () => clearInterval(i); }, []);

    // ---- state machine ----
    const runImmediate = useCallback((id, verbId) => {
      if (CHUNKED.has(verbId)) {
        track(setTimeout(() => {
          const N = 12; let i = 1;
          updateTask(id, { state: 'working', progress: i/N, chunk: [i, N] });
          const step = () => {
            i++;
            if (i <= N) { updateTask(id, { state: 'working', progress: i/N, chunk: [i, N] }); track(setTimeout(step, 360)); }
            else updateTask(id, { state: 'done', progress: 1, result: RESULTS[verbId] || 'Done.', finished: Date.now() });
          };
          track(setTimeout(step, 380));
        }, 1100));
      } else {
        track(setTimeout(() => updateTask(id, { state: 'done', result: RESULTS[verbId] || 'Done.', finished: Date.now() }), 1300));
      }
    }, []);

    const fireJob = useCallback((verb, rest, attach, { echo = true } = {}) => {
      const parsed = parseJob(verb.id, rest);
      let target = parsed.target, targetFull = '';
      if (attach && !target) { target = attach; targetFull = '/Users/me/Desktop/' + attach; }
      const id = nid('t');
      const base = { id, verb: verb.id, target, targetFull, created: Date.now(), source: 'chat' };
      if (parsed.runAt) {
        setTasks(ts => [{ ...base, state: 'scheduled', runAt: parsed.runAt }, ...ts]);
        if (echo) pushMsg({ kind: 'assistant', text: `Scheduled for ${clockTime(parsed.runAt)}. I’ll keep this updated.` });
      } else {
        setTasks(ts => [{ ...base, state: 'running' }, ...ts]);
        if (echo) pushMsg({ kind: 'assistant', text: 'Running now — I’ll keep this updated.' });
        runImmediate(id, verb.id);
      }
      pushMsg({ kind: 'chip', taskId: id });
      return id;
    }, [runImmediate]);

    // ---- chat submit ----
    const onSubmit = useCallback((p) => {
      if (p.type === 'job') {
        const cmd = `/${p.verb.name}${p.rest ? '  ' + p.rest : ''}${p.attach ? '  ' + p.attach : ''}`;
        pushMsg({ kind: 'user', text: cmd });
        if (p.verb.cls === 'held') {
          setConsent({ verb: p.verb, rest: p.rest, attach: p.attach });
          clearTimeout(consentTimer.current);
          consentTimer.current = setTimeout(() => setConsent(null), 14000);
        } else {
          fireJob(p.verb, p.rest, p.attach);
        }
      } else {
        pushMsg({ kind: 'user', text: p.text + (p.attach ? `  · ${p.attach}` : '') });
        const t = p.text.toLowerCase();
        let reply = 'Here’s what I found.';
        if (t.includes('internet') || t.includes('slow') || t.includes('wifi') || t.includes('network'))
          reply = 'Your Wi-Fi looks healthy now — 318 Mbps down, 14 ms latency. There was a brief DNS stall a few minutes ago; it has cleared. Want a full network status?';
        else if (t.includes('hello') || t.includes('hi') || t.includes('hey'))
          reply = 'Hello. Ask me something, or type / to run a job.';
        else if (t.includes('thank')) reply = 'Anytime.';
        else if (t.endsWith('?')) reply = 'I can answer from what’s on this Mac, or run a job to find out. Type / to see what I can do.';
        else reply = 'Noted. If you’d like me to act on that, type / to pick a job.';
        track(setTimeout(() => pushMsg({ kind: 'assistant', text: reply }), 650));
      }
    }, [fireJob]);

    const onConsent = useCallback((ok) => {
      clearTimeout(consentTimer.current);
      const c = consent; setConsent(null);
      if (!c) return;
      if (ok) fireJob(c.verb, c.rest, c.attach, { echo: true });
      else pushMsg({ kind: 'assistant', text: 'Okay — I won’t run that.' });
    }, [consent, fireJob]);

    // ---- voice ----
    const onToggleVoice = useCallback(() => {
      setVoice(v => {
        if (!v) {
          clearTimeout(voiceTimer.current);
          voiceTimer.current = setTimeout(() => { setVoice(false); }, 30000);
          return true;
        } else {
          clearTimeout(voiceTimer.current);
          pushMsg({ kind: 'voice', text: 'what’s slowing my internet?' });
          track(setTimeout(() => pushMsg({ kind: 'assistant', text: 'Your Wi-Fi looks healthy now — 318 Mbps down, 14 ms latency. A brief DNS stall a few minutes ago has cleared.' }), 700));
          return false;
        }
      });
    }, []);

    // ---- view on canvas ----
    const onViewOnCanvas = useCallback((taskId) => {
      const tk = tasks.find(t => t.id === taskId);
      setTab('canvas');
      if (tk) {
        if (tk.state === 'scheduled') setSub('scheduled');
        else if (['done','failed','held'].includes(tk.state)) setSub('activity');
        else setSub('now');
      }
      setHighlightId(taskId);
      setTimeout(() => setHighlightId(null), 2200);
    }, [tasks]);

    // ---- recovery ----
    const onRetry = useCallback((id) => { updateTask(id, { state: 'running', error: null }); const tk = tasks.find(t=>t.id===id); runImmediate(id, tk.verb); }, [tasks, runImmediate]);
    const onChangeTool = useCallback((id, verbId) => {
      updateTask(id, { state: 'running', verb: verbId, error: null });
      if (byId[verbId].cls === 'held') updateTask(id, { state: 'held', hint: 'Switched tool needs approval before running.' });
      else runImmediate(id, verbId);
    }, [runImmediate]);
    const onEditRerun = useCallback((id, newTarget) => {
      const short = newTarget.split('/').pop();
      updateTask(id, { state: 'running', target: short, targetFull: newTarget, error: null });
      const tk = tasks.find(t=>t.id===id); runImmediate(id, tk.verb);
    }, [tasks, runImmediate]);
    const onApprove = useCallback((id) => { const tk = tasks.find(t=>t.id===id); updateTask(id, { state: 'running' }); runImmediate(id, tk.verb); }, [tasks, runImmediate]);
    const onDeny = useCallback((id) => setTasks(ts => ts.filter(t => t.id !== id)), []);
    const onClearCompleted = useCallback(() => setTasks(ts => ts.filter(t => !['done','failed'].includes(t.state))), []);

    // ---- stop everything ----
    const doStop = () => {
      clearTimers();
      setTasks(ts => ts.map(t => ['running','working','queued'].includes(t.state) ? { ...t, state: 'failed', error: 'Stopped by you.', finished: Date.now() } : t));
      setConnected(false); setStopOpen(false); setVoice(false);
      pushMsg({ kind: 'alert', text: 'The assistant was stopped. Reconnect from the menu bar to resume.' });
    };

    useEffect(() => () => { clearTimers(); clearTimeout(consentTimer.current); clearTimeout(voiceTimer.current); }, []);

    const TABS = [
      { id: 'chat', label: 'Chat', icon: 'chat' },
      { id: 'canvas', label: 'Canvas', icon: 'canvas', badge: activeCount },
      { id: 'identity', label: 'Cognitive Identity', icon: 'identity' },
    ];

    return (
      <div className="window" data-theme={theme} data-screen-label="JARVIS window">
        <div className="toolbar">
          <div className="traffic">
            <span className="light-dot close" /><span className="light-dot min" /><span className="light-dot zoom" />
          </div>
          <span className="win-title">JARVIS</span>

          <div className="tabs" role="tablist">
            {TABS.map(t => (
              <button key={t.id} role="tab" aria-selected={tab===t.id}
                className={'tab' + (tab===t.id ? ' active' : '')} onClick={() => setTab(t.id)}>
                <Icon name={t.icon} size={19} className="tab-ico" />
                <span className="tab-label">{t.label}</span>
                {t.badge > 0 && <span className="tab-badge">{t.badge}</span>}
              </button>
            ))}
          </div>

          <div className="toolbar-right">
            <button className={'conn' + (connected ? '' : ' disconnected')} onClick={() => setConnected(c => !c)}
              title="Toggle engine connection (demo)">
              <span className="conn-dot" />
              {connected ? 'Connected' : 'Reconnecting…'}
            </button>
            <button className="icon-btn" onClick={() => setTheme(t => t==='light'?'dark':'light')} title="Toggle appearance" aria-label="Toggle light/dark">
              <Icon name={theme==='light' ? 'moon' : 'sun'} size={16} />
            </button>
            <button className="stop-btn" onClick={() => setStopOpen(true)} title="Stop the assistant">
              <Icon name="stop" size={13} /> Stop
            </button>
          </div>
        </div>

        <div className="content">
          {tab === 'chat' && (
            <window.ChatTab connected={connected} messages={messages} tasks={tasks} consent={consent?.verb}
              onSubmit={onSubmit} onViewOnCanvas={onViewOnCanvas} onConsent={onConsent}
              voice={voice} onToggleVoice={onToggleVoice} />
          )}
          {tab === 'canvas' && (
            <window.CanvasTab tasks={tasks} sub={sub} setSub={setSub} highlightId={highlightId}
              onAdvance={()=>{}} onRetry={onRetry} onChangeTool={onChangeTool} onEditRerun={onEditRerun}
              onApprove={onApprove} onDeny={onDeny} onClearCompleted={onClearCompleted} />
          )}
          {tab === 'identity' && <window.IdentityTab connected={connected} />}
        </div>

        {stopOpen && <StopModal onCancel={() => setStopOpen(false)} onConfirm={doStop} />}
      </div>
    );
  }

  window.App = App;
})();
