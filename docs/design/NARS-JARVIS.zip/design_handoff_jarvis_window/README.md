# Handoff: JARVIS — Unified Assistant Window

## Overview
A single standalone, resizable **macOS desktop window** for NARS-JARVIS, a local-first / privacy-first
assistant. It replaces three cramped menu-bar popovers with one workspace organized as **Command →
Execute → Observe**:

1. **Chat** — a conversation that doubles as a natural-language + `/`-command composer.
2. **Canvas** — a task board where jobs run through a `queued → running → working → done/failed` state
   machine, with inline error recovery and scheduling.
3. **Cognitive Identity** — a calm, privacy-forward view of what the assistant has passively learned.

The window never hijacks the user (firing a job does **not** switch tabs), always makes the parsed job
**visible and correctable**, is honest in its copy (sleep + privacy disclaimers are required and
visible), and must **never imply it can see screen contents**.

---

## About the design files
The files in this bundle are **design references authored in HTML/CSS/React (Babel-in-browser)** — a
high-fidelity prototype showing the intended look, motion, and behavior. **They are not production code
to ship.**

The product is **native macOS (AppKit), macOS 13+**. The task is to **recreate these designs in the
native app** using AppKit components and conventions (`NSWindow`, `NSToolbar`, `NSStackView`/
`NSTableView`/`NSCollectionView`, `NSTextField`/`NSTextView`, `NSProgressIndicator`, `NSMenu`,
`NSPopover`), SF Symbols, semantic system colors, and Auto Layout. SwiftUI is an acceptable alternative
if that's the codebase's direction — but the **mapping notes below assume AppKit** because the brief
specifies it. Treat the React state machine in these files as the **behavioral spec**, not the
implementation.

Where this doc gives hex values, prefer the **system semantic equivalent** (e.g. `NSColor.systemGreen`,
`controlAccentColor`, `labelColor`, `secondaryLabelColor`, `separatorColor`, `NSVisualEffectView`
materials) so light/dark and the user's accent color come for free. The hex values are the design intent
/ fallback.

---

## Fidelity
**High-fidelity.** Final colors, typography, spacing, motion, and interactions. Recreate pixel-faithfully
with native controls. Both **Light and Dark** are first-class and fully specified.

---

## Window shell (global chrome)

| Property | Spec |
|---|---|
| Window | Standard **titled, resizable** `NSWindow`. Real window: appears in window list, minimizable, full-screenable. |
| Title | "JARVIS" |
| Default size | 960 × 680 pt |
| Minimum size | 720 × 520 pt — nothing should clip; content reflows. |
| Level | **Normal** (does NOT float). Does **not** hide on resign-key — it's a persistent workspace. |
| Close | `⌘W` **hides** the window (orderOut), does not quit. Reopen from the menu-bar item. |
| Dock icon | **Recommended: show a Dock icon while the window is open** (`NSApp.setActivationPolicy(.regular)`), flip back to `.accessory` when hidden — gives the "real window" feel. |
| Launch | Summoned from a menu-bar `NSStatusItem` ("JARVIS"). |

### Toolbar (unified title bar)
Height ~52pt, `NSVisualEffectView` (`.titlebar`/`.headerView` material), 0.5pt bottom hairline
(`separatorColor`). Left→right:
- **Traffic lights** (standard window buttons).
- **Window title** "JARVIS" — 13pt semibold, `tertiaryLabelColor`, tracked +0.02em.
- **Tab switcher** (centered) — System-Settings-style segmented set: one item per tab, **icon above a
  10.5pt label**, min 64pt wide, 40pt tall, 7pt corner radius. Selected = `fill` background + full
  `labelColor`; idle = `secondaryLabelColor`. Implement as a custom `NSToolbar` item group or a centered
  `NSSegmentedControl` styled to show icon+label. The **Canvas** tab shows a numeric **active-task
  badge** (red `NSColor.systemRed`, white text, ~16pt, top-right) when ≥1 job is running/working/queued.
- **Right cluster:** connection pill · appearance toggle (icon-only) · **Stop** button.

### Connection status (quiet, never alarming)
- **Connected:** pill with a green dot + "Connected".
- **Disconnected:** **amber** dot with a pulsing ripple + "Reconnecting…" — a reconnecting state, not an
  error. While disconnected: **disable composing**, show a quiet inline bar in Chat, and the Identity tab
  shows a reconnecting empty state. Never look broken/frozen.
- Mirror this on the menu-bar `NSStatusItem`: connected vs. disconnected (e.g. filled vs. outline glyph,
  or a small dot). Don't scream.

### Stop everything (emergency)
Persistent **"Stop"** button in the toolbar-right, tinted with `systemRed` on a 12%-red fill, red
0.5pt hairline. Reachable but not accidentally hit: clicking opens a **confirmation sheet** ("Stop
everything?" → Cancel / destructive "Stop everything"). On confirm: cancel all running/working/queued
jobs (mark Failed "Stopped by you."), set disconnected, post a system notice.

---

## Screens / Views

### TAB 1 — Chat (the Universal Composer)

**Purpose:** talk to the assistant and compose jobs in plain English.

**Layout:** vertical split. Scrollable **transcript** (max content width 720pt, centered, 14pt gap
between rows) fills the top; a pinned **composer zone** at the bottom (0.5pt top separator,
20pt horizontal / 16pt bottom padding).

**Empty state (first run):** centered — 56pt rounded-square glyph (`sparkle`), "What can I do?" (21pt
semibold), "Ask me something, or type **/** to run a job." (13.5pt secondary), then three suggestion
chips: "Summarize a document", "System report", "What's slowing my internet?".

**Message / log row types** (each visually distinct; alignment + color + glyph, never color alone):
| Kind | Treatment |
|---|---|
| **User** | Right-aligned bubble, `controlAccentColor` fill, white text, 14px radius (bottom-right 5px). |
| **Voice transcript** | Same as user bubble + leading `waveform` glyph. |
| **Assistant** | Left-aligned bubble, `fill` (≈8% label) background, `labelColor` text, bottom-left 5px. |
| **Saved/confirmation** | Left, inline green line: `checkmark` + text, `systemGreen`. |
| **System alert / sentinel** | Left card, amber tint (`systemOrange` 16% bg), title "SENTINEL NOTICE" + body. |
| **Error / clarification** | Left card, red tint (`systemRed` 12% bg), `xmark.octagon` glyph + body. |
| **Job acknowledgment** | Becomes the **live status chip** (below). |

**Live status chip** (appears in transcript when a job fires; updates live — see state machine):
rounded 12px, `bg-content-2`, 0.5pt border. Layout: state-tinted 26pt glyph · bold title
"`Verb (target)`" · 1pt divider · state body · trailing **"View on Canvas ›"** link
(`controlAccentColor`). State bodies:
- queued → `hourglass` + "queued"
- running → indeterminate spinner + "working…"
- working → "working" + 70pt determinate mini-bar + mono "chunk i/N"
- done → green `checkmark.circle` + "done"
- failed → red `xmark.octagon` + "failed"
- scheduled → amber `calendar` + "scheduled for 11:00 PM"

**Composer / input bar:** rounded 13px field, `bg-field`, 1pt border (`separatorStrong`); on focus →
accent border + 3px accent focus ring (use the standard focus ring). Left→right controls:
- **`+` attach** (`plus`, icon button) → native `NSOpenPanel`. Chosen file shows as a removable
  **chip/token** (filename + `xmark` in a circle) inside the field. One target per job (v1); design the
  chip so it could stack later.
- **`/` action button** (`slash`) → toggles the action-picker overlay; active state = accent fill.
- **Text field** — auto-growing (1 line → max ~96pt), 13.5px, placeholder "Ask, or type / to run a
  job…" (or, when a verb is pinned, "Add the target and timing… e.g. the PRD on my desktop tonight").
- **🎙 Voice** (`mic`) — push-to-talk. Idle = "Listen"; **recording = `systemRed` fill, white glyph,
  pulsing ring**, plus a hint line "Listening… 0:06 / 0:30 — tap the mic to stop & send". Auto-stops at
  30s.
- **Send** (`arrow.up`) — accent fill, disabled (`fill-3`/`tertiaryLabel`) when empty. `⏎` submits;
  `⇧⏎` newline.
- **Bar states:** empty · focused (ring) · typing · **disabled** (55% opacity, placeholder
  "Reconnecting to the engine…") when disconnected.

**Pinned verb token:** after choosing a verb, it pins as a token at the field's start — `blue-bg` /
`blue` text, the verb name + a tiny Auto/Approval pill — and the user keeps typing the target + timing
after it. `Backspace` at caret position 0 removes the token.

**Inline consent bar** (appears above the input when a **Held** verb is composed): amber bar
(`systemOrange` 16% bg, amber 0.5pt border) — `pause` glyph + "**\<Verb\>** needs your approval — it can
change your system. \<extra for destructive\>" + **Deny** (safe default, plain button) and **Approve**
(affirmative, **green** `systemGreen` fill). Self-dismisses after ~14s (treated as Deny).

**Disconnected bar:** quiet amber strip above input: amber dot + "Disconnected from the engine —
reconnecting. Composing is paused."

---

### TAB 1 detail — The `/` action-picker overlay (marquee interaction)

A **floating, searchable list anchored to the input** (a dropdown, NOT a modal). Implement as an
`NSPopover` or a custom floating panel anchored to the field; open **upward** by default (room above),
and flip to whichever direction has room — must not clip off-screen.

- **Container:** `bg-overlay` (use `NSVisualEffectView` `.popover`/`.menu` material), 12px radius, 0.5pt
  border, drop shadow, blur. Header row ("Run a job — pick an action" / "Actions matching "…"").
- **Rows (max list height ~286pt, scroll):** 30pt rounded icon tile · name (13px) + description (11.5px
  secondary, truncating) · trailing **class pill**.
  - **Autonomous** (safe / read-only): green **"Auto"** pill (`bolt` glyph), `systemGreen` on green tint.
  - **Held** (needs approval / can change system): **amber** **"Needs approval"** pill (`pause` glyph),
    `systemOrange` on amber tint. **Never red.**
- **Focused row:** full `controlAccentColor` fill, white text; the row's icon tile and pill invert to
  translucent white.
- **Search/filter:** live fuzzy filter as the user types after `/` (startsWith → substring → subsequence
  → description match). **No-matches state:** centered `search` glyph + "No actions match "…"." + "Try
  "summarize", "network", or "open"."
- **Keyboard:** `↑`/`↓` move selection (wrap not required), `⏎` choose, `Esc` dismiss. Footer shows these
  hints with `kbd` styling.
- **After choosing:** the verb pins into the input as the token (above) and focus returns to the field.

**Catalog (verbs)** — friendly name · description · class · **SF Symbol**:
| Verb | Description | Class | SF Symbol |
|---|---|---|---|
| Summarize a document | Condense a local file into key points | Auto | `doc.text.magnifyingglass` |
| Read a web article | Fetch and read an online page | Auto | `globe` |
| Read a file | Open and read a local file | Auto | `doc.text` |
| Web search | Search the web for a query | Auto | `magnifyingglass` |
| System report | A snapshot of this Mac's health | Auto | `gauge.with.dots.needle.67percent` |
| Audio status | Current output device and volume | Auto | `speaker.wave.2` |
| Network status | Connection, signal, and throughput | Auto | `wifi` |
| Largest apps | Apps using the most disk space | Auto | `chart.bar` |
| Find a file | Locate a file by name | Auto | `doc.text.magnifyingglass` |
| Open an app | Launch an application | **Held** | `app.dashed` |
| Open a URL | Open a link in your browser | **Held** | `link` |
| Set volume | Change the system output volume | **Held** | `speaker.wave.2` |
| Mute | Silence system audio | **Held** | `speaker.slash` |
| Empty trash | Permanently delete trashed items | **Held** | `trash` |

---

### TAB 2 — Canvas (task board / monitor)

> **Removed:** the old click-to-build action palette. Canvas is a **monitor / management** surface only —
> composing happens in Chat. Do not build a palette.

**Purpose:** watch jobs run, recover failures, manage scheduled work.

**Header:** a **segmented control** (Now · Scheduled · Activity) with per-segment count badges; on
Activity, a trailing **"Clear completed"** button. All three sub-tabs render the **same Task Row**
filtered by state.

**Empty states:** Now → "Nothing running." / "Start a job from Chat and watch it here." · Scheduled →
"Nothing scheduled." · Activity → "No finished tasks yet."

#### The Task Row — the centerpiece component (one row, six states)
Container: 0.5px border, 11px radius, `bg-content-2`. Main row: 34pt state-tinted glyph · titles ·
trailing state **badge**. Title = "**Verb** — `target`" (target is **monospaced**, secondary).
Subtitle depends on state. Body depends on state:

| State | Glyph / color | Badge | Body |
|---|---|---|---|
| **QUEUED** | `hourglass`, neutral grey | "Queued" | subtitle "Waiting to start" |
| **RUNNING** | `play`, blue | "Running" | **indeterminate** progress bar |
| **WORKING** | `play`, blue | "Working" | **determinate** progress bar + mono "chunk i / N" |
| **DONE** | `checkmark.circle`, green | "Done" | **selectable, copyable result panel** (below) |
| **FAILED** | `xmark.octagon`, red | "Failed" | error message + **recovery controls** (below) |
| **HELD** | `pause`, amber | "Needs approval" | hint + **Deny** / **Approve & run** (green) |
| **SCHEDULED** | `calendar`, amber | "Scheduled" | subtitle = clock time + **countdown** ("in 6 h 40 m") + the disclaimer |

State colors are **functional**: done=green, in-progress=blue/accent, held/scheduled=amber, failed=red,
queued=neutral grey. Pair color with a glyph + text label everywhere (never color alone).

- **Result panel (DONE):** inset card, header "RESULT" + **Copy** + **Expand/Collapse** (collapse long
  results to ~92pt with a fade mask). Body is **monospaced, user-selectable**, scrolls past ~260pt.
- **Recovery (FAILED)** — three affordances under the error:
  1. **↻ Retry** — re-run the same job (transient failures).
  2. **Change tool ▾** — dropdown ("Send the same target to…") of **alternative verbs that accept the
     same target kind** (file vs. url/query). Each row shows its Auto/Approval pill. **Empty state:** "No
     alternative for this input." (Example: a local `.pdf` sent to *Read a web article* offers
     *Summarize a document* / *Read a file*.)
  3. **Edit target + Re-run** — an **inline editable** monospaced field pre-filled with the path/URL +
     **Cancel** / **Re-run**. Lets the user fix a typo or hallucinated path without redoing the request.
- **Hover/selected/expanded:** Done/Failed rows are click-to-expand/collapse (chevron). A row navigated
  to via "View on Canvas" gets a **highlight** (accent border + 3px accent ring) for ~2.2s.

**Scheduled sub-tab also shows:**
- **Quick-schedule presets** (a button set): **Tonight 2 AM · In 1 hour · In 4 hours** (first selected by
  default). **No full date picker** in v1.
- **The honest sleep disclaimer — visible, not a tooltip**, on every scheduled row (amber inset):
  *"Runs at the set time if your Mac is awake — otherwise on the next wake. Nothing runs while it's off."*

**Activity sub-tab:** "Held for approval" section (Deny / Approve & run) then "Completed & failed"
(Done/Failed rows with results/errors + recovery), plus **Clear completed**.

---

### TAB 3 — Cognitive Identity (the passive mirror)

**Purpose:** show what the assistant has passively learned. Calm, reflective, privacy-forward.

**Header:** "Cognitive Identity" (19pt bold) + a manual **Refresh** (`refresh`, spins while refreshing).
Content max width 680pt, centered.

**The Mirror card** (`bg-content-2`, 14px radius):
- Title "What I've noticed about your computer use" + meta "3 hours · 108 app switches" + an `eye` glyph
  tile.
- **"Most of your time"** — horizontal bars per app, colored **by kind**, with a monospaced duration on
  the right. Sample: Cursor 2 h 10 m (development/blue), Chrome 1 h 5 m (communication/amber), Terminal
  8 m (development/blue), Music 5 m (media/green).
- **"By kind"** — colored-dot chips (development, communication, media).
- **"Busiest around"** — `clock` + "3 PM".
- **Privacy line (ALWAYS present, italic, top-bordered):** *"Learned from which app is in front — never
  your screen contents."*
- **Not-enough-data state:** centered `sparkle` + "Still learning" + "Give me a couple more days of
  normal use…" + the privacy line.

**Learned habits list:** rows with a **[Active]** (green) or **[Learning]** (amber) tag + the
plain-English habit + a **Forget** control. Forget shows an inline confirm ("Forget this?" → Keep /
destructive **Forget**).

**Style & preferences list:** same row pattern with an accent dot + Forget. Plain-English inferred
preferences.

**States:** loading · populated · learning/empty · **disconnected** (reconnecting empty state).

---

## Interactions & behavior (rules the implementation must honor)
1. **Never hijack.** Firing a job does **not** switch tabs or steal focus. Progress surfaces in place
   (the chip) + the ambient Canvas badge; navigation to Canvas is **user-initiated** ("View on Canvas").
2. **Model proposes, code disposes.** Every parsed job appears as a visible row **before/while** it runs,
   correctable via Change-tool / Edit-target. Never run silently.
3. **Honest copy.** The sleep disclaimer and privacy line are required, visible, non-hidden.
4. **Two action classes** (Auto vs. Held) styled **consistently everywhere** (picker, rows, Activity).
5. **Resilient to disconnection.** Quiet reconnecting state, compose disabled, never looks broken.

**Motion (subtle, native):** tab switches **instant**; entrance = a short **transform-only** rise/scale
(~190–280ms, ease-out) — **do not animate opacity for content reveal** (content must be visible even if
animation never runs); progress bars animate width smoothly (~360ms); recording mic pulses; disconnected
dot ripples. No bouncy/consumer animations. Respect `prefers-reduced-motion`.

**Native notifications:** when the window isn't focused, the app posts macOS notifications for
alerts/consent — match this voice/tone (calm, honest, owns its limits).

---

## State machine (behavioral spec — see app.jsx)
- **Immediate job:** `running` → (chunked verbs: `working` advancing `chunk i/N`, i = 1…12,
  progress = i/N, ~360ms/step) → `done` (with result). Non-chunked verbs: `running` → `done` (~1.3s).
- **Scheduled job** (timing parsed from text): `scheduled` with `runAt`; shows countdown + disclaimer.
- **Held verb from Chat:** routes through the **consent bar** first; Approve → run, Deny → "Okay — I
  won't run that."
- **Recovery:** Retry → `running` again; Change-tool → swap verb (→ `held` if the new verb is Held, else
  run); Edit-target → update path then `running`.
- **Stop everything:** cancel all active → `failed` "Stopped by you.", set disconnected.

**Chat state:** `theme`, `tab`, `sub`, `connected`, `tasks[]`, `messages[]`, `consent`, `voice`,
`highlightId`. **Task shape:** `{ id, verb, target, targetFull, state, progress, chunk:[i,N], result,
error, runAt, finished, hint, source }`.

**Timing parser (plain English → schedule):** "tonight"/"11 pm" → 11 PM today (or next day), "2 am" →
2 AM tomorrow, "in 1 hour", "in N hours". Strips filler ("the", "on my desktop", "my", "please") to get
the target. This is a stand-in; the real engine parses on the backend.

---

## Design tokens (exact values)

**Prefer system semantic colors**; these hexes are the design intent / fallback.

### Light
| Token | Value | Native equivalent |
|---|---|---|
| window bg | `#ECECEC` | window background |
| content bg | `#FFFFFF` | `controlBackgroundColor` |
| content-2 (cards/rows) | `#F6F6F8` | `windowBackgroundColor`/secondary |
| toolbar | `rgba(246,246,246,.82)` blur | `NSVisualEffectView .titlebar` |
| separator | `rgba(0,0,0,.10)` | `separatorColor` |
| label | `rgba(0,0,0,.85)` | `labelColor` |
| label-2 | `rgba(0,0,0,.50)` | `secondaryLabelColor` |
| label-3 | `rgba(0,0,0,.28)` | `tertiaryLabelColor` |
| fill | `rgba(0,0,0,.05)` | control fill |
| accent | `#0A6DFF` | `controlAccentColor` |
| green / bg | `#1E8E3E` / `systemGreen 16%` | `systemGreen` |
| blue / bg | `#0A6DFF` / `accent 12%` | accent |
| amber / bg | `#B25E00` / `systemOrange 18%` | `systemOrange` |
| red / bg | `#D70015` / `systemRed 12%` | `systemRed` |
| grey / bg | `rgba(0,0,0,.5)` / `6%` | `systemGray` |

### Dark
| Token | Value |
|---|---|
| window bg | `#1E1E1E` |
| content bg | `#1E1E1E` |
| content-2 | `#2A2A2C` |
| toolbar | `rgba(46,46,48,.74)` blur |
| separator | `rgba(255,255,255,.12)` |
| label | `rgba(255,255,255,.92)` |
| label-2 | `rgba(255,255,255,.55)` |
| label-3 | `rgba(255,255,255,.32)` |
| fill | `rgba(255,255,255,.07)` |
| accent | `#0A84FF` |
| green / blue / amber / red | `#30D158` / `#0A84FF` / `#FF9F0A` / `#FF453A` (system dark variants) |

### Typography
System font (SF Pro / `-apple-system`). Monospace = **SF Mono** (`ui-monospace`) for results, file
paths, IDs, "chunk i/N" — and these must be **selectable**.
| Role | Size / weight |
|---|---|
| Tab-title (window) | 13 semibold |
| Large title (Identity / empty) | 19–21, 600–700 |
| Section header | 11, 600, uppercase, +0.04em tracking, tertiary |
| Body / bubbles | 13–13.5 |
| Row title | 13.5 semibold |
| Secondary / meta | 11–12.5 |
| Pills / badges | 10.5–11, 600 |
| Mono (results/paths) | 12, SF Mono |
Support **Dynamic Type** — nothing fixed that clips at larger sizes.

### Spacing / radius / shadow
- Spacing scale: **2 · 4 · 6 · 8 · 12 · 16 · 20 · 24**.
- Radius: control **6–7**, card **8–11**, window **11**, pill **999**, bubble **14** (one corner 5).
- Focus ring: 3px accent at ~18% (use the standard AppKit focus ring).
- Shadows: window deep ambient; overlays/popovers medium; cards 0–1px hairline + faint shadow.
- Density: comfortable but information-dense (it's an all-day workspace).

---

## Iconography (SF Symbols)
- **Tabs:** Chat `message` (or `bubble.left.and.bubble.right`), Canvas `square.grid.2x2`, Cognitive
  Identity `person.crop.circle` (or `brain`).
- **States:** queued `hourglass`, running/working `play.fill` + `NSProgressIndicator`, done
  `checkmark.circle`, failed `xmark.octagon`, held `pause.circle`, scheduled `calendar`.
- **Controls:** attach `plus`, action `slash`, voice `mic` / recording `mic.fill`, send `arrow.up`,
  retry/refresh `arrow.clockwise`, change-tool `arrow.left.arrow.right`, edit `pencil`, forget `eraser`,
  stop `stop.circle`, appearance `moon`/`sun`, privacy `eye.slash`, mirror `eye`, info `info.circle`,
  approve `checkmark`.
- **Verb symbols:** see the Catalog table above.

A11y: every control needs a VoiceOver label; task **state and progress** must be announced; full keyboard
operation (`⏎` send, `/` picker, `↑↓⏎Esc` in picker, Tab order, `⌘W` close); **WCAG AA** contrast in both
modes; never rely on color alone.

---

## Assets
- **No raster assets.** All iconography is **SF Symbols** (names above) — use native symbols in the app.
  The prototype draws SF-Symbol-style monoline SVGs only as stand-ins (`icons.jsx`).
- **No custom fonts** — system SF Pro + SF Mono.
- **Sample/seed content** (jobs, mirror data, results) lives in `data.jsx` and `app.jsx` for reference;
  real data comes from the engine.

---

## Files in this bundle
| File | Contents |
|---|---|
| `index.html` | Entry point; loads React + Babel, mounts the app, viewport scaling. |
| `styles.css` | Design tokens (light/dark) + window shell + shared primitives (buttons, pills, badges, progress, spinner). |
| `components.css` | Per-tab styling (Chat, Canvas, Cognitive Identity, modal). |
| `icons.jsx` | SF-Symbol-style icon set (each documented with its SF Symbol name). |
| `data.jsx` | Verb catalog, seed tasks, mirror/habits/persona data, the timing parser + time helpers. |
| `chat.jsx` | Chat tab: transcript rows, live chip, `/` picker overlay, attach chip, consent bar, input bar. |
| `canvas.jsx` | Canvas tab: segmented sub-tabs, the Task Row (all 6 states), result panel, change-tool menu, path editor, presets. |
| `identity.jsx` | Cognitive Identity tab: mirror card, learning state, habit/persona rows + Forget. |
| `app.jsx` | Window shell, toolbar, global state, the task state-machine runner, Stop-everything sheet. |

**To run the prototype:** open `index.html` in a browser. Toggle Light/Dark with the moon/sun button;
toggle the connection state by clicking the "Connected" pill.
