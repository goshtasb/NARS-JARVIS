/* data.jsx — catalog of verbs, sample content, and helpers.
   Shared globally via window.* (Babel scripts don't share scope). */
(function () {
  // ---- Action catalog (verbs). class: 'auto' (autonomous, read-only/safe)
  //      or 'held' (needs approval — can change the system). icon = SF Symbol name. ----
  const CATALOG = [
    { id: 'summarize',  name: 'Summarize a document', desc: 'Condense a local file into key points', icon: 'doc.text',    cls: 'auto', sym: 'doc.text.magnifyingglass', target: 'file' },
    { id: 'readweb',    name: 'Read a web article',   desc: 'Fetch and read an online page',          icon: 'globe',       cls: 'auto', sym: 'globe', target: 'url' },
    { id: 'readfile',   name: 'Read a file',          desc: 'Open and read a local file',             icon: 'doc',         cls: 'auto', sym: 'doc.text', target: 'file' },
    { id: 'websearch',  name: 'Web search',           desc: 'Search the web for a query',             icon: 'search',      cls: 'auto', sym: 'magnifyingglass', target: 'query' },
    { id: 'sysreport',  name: 'System report',        desc: 'A snapshot of this Mac\u2019s health',   icon: 'gauge',       cls: 'auto', sym: 'gauge.with.dots.needle.67percent' },
    { id: 'audio',      name: 'Audio status',         desc: 'Current output device and volume',       icon: 'speaker',     cls: 'auto', sym: 'speaker.wave.2' },
    { id: 'network',    name: 'Network status',       desc: 'Connection, signal, and throughput',     icon: 'wifi',        cls: 'auto', sym: 'wifi' },
    { id: 'largest',    name: 'Largest apps',         desc: 'Apps using the most disk space',         icon: 'chart',       cls: 'auto', sym: 'chart.bar' },
    { id: 'findfile',   name: 'Find a file',          desc: 'Locate a file by name',                  icon: 'doc.search',  cls: 'auto', sym: 'doc.text.magnifyingglass', target: 'query' },
    { id: 'openapp',    name: 'Open an app',          desc: 'Launch an application',                  icon: 'app',         cls: 'held', sym: 'app.dashed', target: 'query' },
    { id: 'openurl',    name: 'Open a URL',           desc: 'Open a link in your browser',            icon: 'link',        cls: 'held', sym: 'link', target: 'url' },
    { id: 'setvolume',  name: 'Set volume',           desc: 'Change the system output volume',        icon: 'speaker',     cls: 'held', sym: 'speaker.wave.2' },
    { id: 'mute',       name: 'Mute',                 desc: 'Silence system audio',                   icon: 'speaker.slash', cls: 'held', sym: 'speaker.slash' },
    { id: 'emptytrash', name: 'Empty trash',          desc: 'Permanently delete trashed items',       icon: 'trash',       cls: 'held', sym: 'trash' },
  ];
  const byId = Object.fromEntries(CATALOG.map(v => [v.id, v]));

  // ---- Seed tasks for the Canvas board (real-data shaped) ----
  const SUMMARY_RESULT = `Q3 PRD — executive summary

The document proposes shipping the unified JARVIS window in Q3, replacing the three menu-bar popovers with one resizable workspace. Three goals are named: reduce time-to-first-job, make every parsed job visible and correctable, and keep the privacy invariant intact.

Key decisions
\u2022 Composition moves entirely into Chat (natural language + the / picker). The Canvas drag-palette is removed.
\u2022 Jobs surface in place via a live chip; the app never auto-switches tabs.
\u2022 Scheduling ships with presets only (Tonight 2 AM / In 1 hour / In 4 hours); a full date picker is deferred.

Risks
\u2022 Parser ambiguity on file vs. URL targets — mitigated by the failed-row "Change tool" recovery.
\u2022 Sleep behavior must be communicated honestly; the disclaimer is required on every scheduled job.

Recommendation: proceed. Estimated 6 weeks, one engineer, contingent on the local model fitting the latency budget.`;

  function now() { return Date.now(); }
  const seedTasks = () => ([
    {
      id: 't1', verb: 'summarize', target: 'Q3-PRD.pdf', targetFull: '/Users/me/Desktop/Q3-PRD.pdf',
      state: 'working', progress: 0.58, chunk: [7, 12], created: now() - 40000, source: 'chat',
    },
    {
      id: 't2', verb: 'network', target: '', state: 'running', created: now() - 8000, source: 'chat',
    },
    {
      id: 't3', verb: 'sysreport', target: '', state: 'scheduled',
      runAt: now() + 6 * 3600e3 + 40 * 60e3, created: now() - 120000, source: 'chat',
    },
    {
      id: 't4', verb: 'summarize', target: 'weekly-notes.md', targetFull: '/Users/me/Desktop/weekly-notes.md',
      state: 'scheduled', runAt: now() + 1 * 3600e3, created: now() - 90000, source: 'chat',
    },
    {
      id: 't5', verb: 'summarize', target: 'Q3-PRD.pdf', targetFull: '/Users/me/Desktop/Q3-PRD.pdf',
      state: 'done', result: SUMMARY_RESULT, created: now() - 600000, finished: now() - 480000, source: 'chat',
    },
    {
      id: 't6', verb: 'readweb', target: '/Users/me/PRD.pdf', targetFull: '/Users/me/PRD.pdf',
      state: 'failed', error: 'That\u2019s a local file, not a web page \u2014 try \u201cSummarize a document.\u201d',
      created: now() - 720000, finished: now() - 700000, source: 'chat',
    },
    {
      id: 't7', verb: 'emptytrash', target: '', state: 'held',
      hint: 'This permanently deletes items \u2014 I won\u2019t run it without your OK.',
      created: now() - 300000, source: 'chat',
    },
  ]);

  // ---- Cognitive Identity seed ----
  const MIRROR = {
    windowHours: 3, switches: 108,
    apps: [
      { name: 'Cursor', mins: 130, kind: 'development' },
      { name: 'Chrome', mins: 65, kind: 'communication' },
      { name: 'Terminal', mins: 8, kind: 'development' },
      { name: 'Music', mins: 5, kind: 'media' },
    ],
    kinds: ['development', 'communication', 'media'],
    busiest: '3 PM',
  };
  const HABITS = [
    { id: 'h1', text: 'You open Cursor and Terminal together most mornings around 9 AM.', state: 'active' },
    { id: 'h2', text: 'You usually take a media break (Music) in the mid-afternoon lull.', state: 'active' },
    { id: 'h3', text: 'You seem to batch communication apps in the late afternoon.', state: 'learning' },
  ];
  const PERSONA = [
    { id: 'p1', text: 'Prefers short, direct answers over long explanations.' },
    { id: 'p2', text: 'Works mostly in development tools; comfortable with file paths and the terminal.' },
    { id: 'p3', text: 'Likes jobs scheduled for late night rather than interrupting the workday.' },
  ];

  // ---- Verb matcher for the / picker (simple fuzzy/substring) ----
  function filterVerbs(q) {
    q = (q || '').trim().toLowerCase();
    if (!q) return CATALOG;
    const score = (v) => {
      const n = v.name.toLowerCase(), d = v.desc.toLowerCase();
      if (n.startsWith(q)) return 0;
      if (n.includes(q)) return 1;
      // fuzzy subsequence on name
      let i = 0; for (const ch of n) { if (ch === q[i]) i++; if (i === q.length) break; }
      if (i === q.length) return 2;
      if (d.includes(q)) return 3;
      return 99;
    };
    return CATALOG.map(v => [v, score(v)]).filter(([, s]) => s < 99)
      .sort((a, b) => a[1] - b[1]).map(([v]) => v);
  }

  // ---- Parse free text after a pinned verb into target + timing ----
  const SCHED = [
    { re: /tonight|11\s*pm|11pm/i, label: 'Tonight 11 PM', at: () => atToday(23, 0) },
    { re: /2\s*am|tonight 2|2am/i, label: 'Tonight 2 AM', at: () => atTomorrow(2, 0) },
    { re: /in (an?|1) hour/i, label: 'in 1 hour', at: () => Date.now() + 3600e3 },
    { re: /in (\d+) hours?/i, label: 'in 4 hours', at: (m) => Date.now() + parseInt(m[1], 10) * 3600e3 },
  ];
  function atToday(h, m) { const d = new Date(); d.setHours(h, m, 0, 0); if (d < new Date()) d.setDate(d.getDate() + 1); return d.getTime(); }
  function atTomorrow(h, m) { const d = new Date(); d.setDate(d.getDate() + 1); d.setHours(h, m, 0, 0); return d.getTime(); }

  function parseJob(verbId, rest) {
    rest = (rest || '').trim();
    let runAt = null, schedLabel = null;
    for (const s of SCHED) {
      const m = rest.match(s.re);
      if (m) { runAt = s.at(m); schedLabel = s.label; rest = rest.replace(s.re, '').trim(); break; }
    }
    let target = rest.replace(/\b(the|on my desktop|my|please)\b/gi, '').replace(/\s+/g, ' ').trim();
    return { verbId, target, runAt, schedLabel };
  }

  // ---- time helpers ----
  function relTime(ms) {
    const d = Math.max(0, ms - Date.now());
    const h = Math.floor(d / 3600e3), m = Math.floor((d % 3600e3) / 60e3);
    if (h > 0) return `in ${h} h ${m} m`;
    if (m > 0) return `in ${m} m`;
    return 'in <1 m';
  }
  function clockTime(ms) {
    return new Date(ms).toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' });
  }
  function fmtMins(m) {
    const h = Math.floor(m / 60), mm = m % 60;
    if (h > 0) return `${h} h ${mm} m`;
    return `${mm} m`;
  }

  window.JARVIS = {
    CATALOG, byId, seedTasks, MIRROR, HABITS, PERSONA,
    filterVerbs, parseJob, relTime, clockTime, fmtMins, SUMMARY_RESULT,
  };
})();
